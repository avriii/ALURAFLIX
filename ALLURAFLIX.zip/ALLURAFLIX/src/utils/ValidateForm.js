export const validateForm = async (formData) => {
    const errors = {};

    const trimField = (field, fieldName, minLen, maxLen) => {
        const trimmedValue = field ? field.toString().trim() : '';
        if (!trimmedValue) {
            errors[fieldName] = `El campo ${fieldName} es requerido.`;
        } else if (trimmedValue.length < minLen) {
            errors[fieldName] = `El campo ${fieldName} debe tener al menos ${minLen} caracteres.`;
        } else if (trimmedValue.length > maxLen) {
            errors[fieldName] = `El campo ${fieldName} no puede tener más de ${maxLen} caracteres.`;
        }
        return trimmedValue;
    };

    // Validate title
    trimField(formData.title, 'título', 3, 200);

    // Validate category
    trimField(formData.category, 'categoría', 1, Infinity); // Ajustar según requisitos

    // Validate photo URL
    trimField(formData.photo, 'URL de la foto', 1, Infinity); // Ajustar según requisitos
    if (formData.photo && !isPhotoURLValid(formData.photo)) {
        errors.photo = 'La URL de la foto no es válida o no es una foto válida.';
    }

    // Validate video URL
    trimField(formData.link, 'URL del video', 1, Infinity); // Ajustar según requisitos
    if (formData.link && !isVideoURLValid(formData.link)) {
        errors.link = 'La URL del video no es válida o no es un video válido.';
    }

    // Validate description
    trimField(formData.description, 'descripción', 3, 500);

    return errors;
};

// Validate photo URL
const isPhotoURLValid = (url) => /\.(jpg|jpeg|png|gif)$/i.test(url);

// Validate video URL
const isVideoURLValid = (url) => /^https:\/\/www\.youtube\.com\/embed\/[a-zA-Z0-9_-]+\?si=[a-zA-Z0-9_-]+$/.test(url);
